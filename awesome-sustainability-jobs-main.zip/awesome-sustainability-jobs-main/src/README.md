To develop locally you need nix.

`nix develop .` will get you into a nix shell with all required dependencies.
